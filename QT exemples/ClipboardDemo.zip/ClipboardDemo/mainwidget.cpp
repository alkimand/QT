#include "mainwidget.h"
#include "ui_mainwidget.h"

#include <QClipboard>
#include <QMimeData>
#include <QDebug>

MainWidget::MainWidget( QWidget* parent ) :
    QWidget( parent ),
    ui( new Ui::MainWidget ) {
    ui->setupUi( this );

    if( QClipboard* c = QApplication::clipboard() ) {
        connect( c, SIGNAL( dataChanged() ), SLOT( onClipboardChanged() ) );
    }

    connect( ui->lstHistory, SIGNAL( doubleClicked( QModelIndex ) ), SLOT( onListDbClicked( QModelIndex ) ) );
}

MainWidget::~MainWidget() {
    delete ui;
}

void MainWidget::onClipboardChanged() {
    if( QClipboard* c = QApplication::clipboard() ) {
        if( const QMimeData* m = c->mimeData() ) {
            if( m->hasText() ) {
                ui->lstHistory->insertItem( 0, m->text() );
            }
        }
    }
}

void MainWidget::onListDbClicked( const QModelIndex& index ) {
    const QString& text = ui->lstHistory->item( index.row() )->text();
    if( QClipboard* c = QApplication::clipboard() ) {
        c->disconnect( this );
        c->setText( text );
        connect( c, SIGNAL( dataChanged() ), SLOT( onClipboardChanged() ) );
    }
}
