#ifndef LISTWIDGET_H
#define LISTWIDGET_H


#include <QListWidget>
#include <QObject>


class ListWidget : public QListWidget
{
    Q_OBJECT
public:
    ListWidget(QWidget *parent = nullptr);

protected:

void mouseMoveEvent(QMouseEvent* event);
void dropEvent(QDropEvent *event);
void dragEnterEvent(QDragEnterEvent *event);

};

#endif // LISTWIDGET_H
