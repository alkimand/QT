#include "listwidget.h"

#include <QtGui>

ListWidget::ListWidget(QWidget *parent) : QListWidget(parent)
{
    setDragEnabled(true);
    viewport()->setAcceptDrops(true);
    setDragDropOverwriteMode(false);
    setDropIndicatorShown(true);
    setSelectionMode(QAbstractItemView::MultiSelection);
    setSelectionBehavior(QAbstractItemView::SelectRows);
    setDragDropMode(QAbstractItemView::InternalMove);

}


void ListWidget::mouseMoveEvent(QMouseEvent* event)
{
    Q_UNUSED(event)
    QList<QListWidgetItem*> items = this->selectedItems();
    QList<QUrl> urls;

    for(QListWidgetItem* item: items)
    urls << QUrl::fromLocalFile(item->text());


    QDrag* drag = new QDrag(this);
    QMimeData* mimeData = new QMimeData;
    mimeData->setUrls(urls);
    drag->setMimeData(mimeData);
    //drag->exec(Qt::CopyAction);//скопировать
    drag->exec(Qt::MoveAction);//переместить

    for(QListWidgetItem* item: items)
    delete item;


}
void ListWidget::dropEvent(QDropEvent *event)
{
    const QMimeData *mimedata = event->mimeData();

       if(mimedata->hasUrls())
       {
           QList<QUrl> urllist = mimedata->urls();
           for(QUrl url: urllist)
           {
           QString filename = url.toLocalFile();
           this->addItem(filename);
           }
       }


}
void ListWidget::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasUrls())
        event->acceptProposedAction();
}
