In order to compile these examples, use at least Qt 5.3.0. 

The commands for Windows, Mac OS X and Linux builds:
Windows (MinGW C++) : qmake
                      mingw32-make
Windows (Visual C++) : qmake
                       nmake
Mac OS X: qmake -spec macx-g++; make
Linux: qmake; make

Note: 
  You can also use for the compiling "Qt Creator"
